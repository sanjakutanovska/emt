package mk.ukim.finki.emt.lab2application.model.enums;

public enum Category {
    NOVEL, THRILLER, HISTORY, FANTASY, BIOGRAPHY, CLASSICS, DRAMA
}
